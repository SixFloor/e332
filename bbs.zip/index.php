<?php
define('ALPHABET', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789');
$encrypt_page=true;
$gzip_page=true;
$mirror = "mingbbs.9947.eu.org";

function code($w,$k,$d) {
	if ($w=='decrypt'){$d=base64_decode(strtr($d,$k,ALPHABET.'+/'));}
	if ($w=='encrypt'){$d=strtr(rtrim(base64_encode($d),'='),ALPHABET.'+/',$k);}
	return $d;
}
function encodePage($input) {
	$parts=array();
	if(preg_match('#^(.*?)<head[^>]*>(.*?)</head>\s*<body([^>]*)>(.*)</body>(.*?)</html>(.*)$#is',$input,$parts)){
		unset($parts[0]);
		$meta1=preg_match('#\s?<meta.+?charset=[^\w]?([-\w]+)[^>]+>\s?#is',$parts[2],$tmp)?$tmp[0]:null;
		$meta2=preg_match('#<meta http-equiv="X-UA-Compatible".+?content=[^\w]?([=\w]+)[^>]+>\s?#i',$parts[2],$tmp)?$tmp[0]:null;
		$parts[1].="<head>\n".$meta1.$meta2.injectionJS();
		$parts[2]=str_replace(array($meta1,$meta2),'',$parts[2]);
		$parts[2]=encodeBlock($parts[2])."\n</head>";
		$parts[3]="\n<body{$parts[3]}>\n";
		$parts[4]=encodeBlock($parts[4])."\n</body>";
		$parts[5]=encodeBlock($parts[5])."\n</html>\n";
		#$parts[6]=encodeBlock($parts[6]);
	}else return $input; #���۲�����ҳ������ȷƥ�䣬ֱ�ӷ���input��
	return implode('',$parts);
}
function encodeBlock($input) {
	global $psd,$dec;
	if(empty($input))return '';
	return '<script type="text/javascript">document.write('.$dec.'(\''.code('encrypt',$psd,$input) .'\'));</script>';
}
function injectionJS() {
	global $psd,$dec;
	return <<<OUT
<script type="text/javascript">function {$dec}(d){var q='{$psd}';var z,y,x,w,v,u,t,s,p=d.length,i=0,j=0,r=[];do{w=q.indexOf(d.charAt(i++));v=q.indexOf(d.charAt(i++));u=q.indexOf(d.charAt(i++));t=q.indexOf(d.charAt(i++));s=w<<18|v<<12|u<<6|t;z=s>>16&0xff;y=s>>8&0xff;x=s&0xff;r[j++]=String.fromCharCode(z,y,x);}while(i<p);return r.join('');}</script>
OUT;
}

if(!isset($psd))$psd=substr(str_shuffle(ALPHABET.'+/`~!@$^*_-|;:?,.'),0,64);
if(!isset($dec))$dec='_'.substr(str_shuffle(ALPHABET),0,4);

$req = $_SERVER['REQUEST_METHOD'] . ' ' . $_SERVER['REQUEST_URI'] . " HTTP/1.0\r\n";
$length = 0;
foreach ($_SERVER as $k => $v) {
	if (substr($k, 0, 5) == "HTTP_") {
		$k = str_replace('_', ' ', substr($k, 5));
		$k = str_replace(' ', '-', ucwords(strtolower($k)));
		if ($k == "Host")
			$v = $mirror;						# Alter "Host" header to mirrored server
		if ($k == "Accept-Encoding")
			$v = "identity;q=1.0, *;q=0";		# Alter "Accept-Encoding" header to accept unencoded content only
		if ($k == "Keep-Alive")
			continue;							# Drop "Keep-Alive" header
		if ($k == "Connection" && $v == "keep-alive")
			$v = "close";						# Alter value of "Connection" header from "keep-alive" to "close"
		$req .= $k . ": " . $v . "\r\n";
	}
}
$body = @file_get_contents('php://input');
$req .= "Content-Type: " . $_SERVER['CONTENT_TYPE'] . "\r\n";
$req .= "Content-Length: " . strlen($body) . "\r\n";
$req .= "\r\n";
$req .= $body;

#print $req;

$fp = fsockopen($mirror, 80, $errno, $errmsg, 30);
if (!$fp) {
	print "HTTP/1.0 502 Failed to connect remote server\r\n";
	print "Content-Type: text/html\r\n\r\n";
	print "<html><body>Failed to connect to $mirror due to:<br>[$errno] $errstr</body></html>";
	exit;
}

fwrite($fp, $req);

$headers_processed = 0;
$reponse = '';
$doc='';
$types = array(
	'text/javascript'							=> 'javascript',
	'text/ecmascript'							=> 'javascript',
	'application/javascript'					=> 'javascript',
	'application/x-javascript'					=> 'javascript',
	'application/ecmascript'					=> 'javascript',
	'application/x-ecmascript'					=> 'javascript',
	'text/livescript'							=> 'javascript',
	'text/jscript'								=> 'javascript',
	'application/xhtml+xml'						=> 'html',
	'text/html'									=> 'html',
	'text/css'									=> 'css',
	'text/xml'									=> 'rss',
	'application/x-msdownload'					=> 'exe',
	'application/vnd.android.package-archive'	=> 'apk',
	'video/x-flv'								=> 'flv',
	'video/mp4'									=> 'mp4',
	'application/zip'							=> 'zip',
	'application/octet-stream'					=> 'binary',
	'image/jpeg'								=> 'image',
	'image/gif'									=> 'image',
	'image/png'									=> 'image',
#	'application/rss+xml'		=> 'rss',
#	'application/rdf+xml'		=> 'rss',
#	'application/atom+xml'		=> 'rss',
#	'application/xml'			=> 'rss',
);
while (!feof($fp)) {
	$r = fread($fp, 8192);
	if (!$headers_processed) {
		$response = $r;
		$nlnl = strpos($response, "\r\n\r\n");
		$add = 4;
		if (!$nlnl) {
			$nlnl = strpos($response, "\n\n");
			$add = 2;
		}
		if (!$nlnl)
			continue;
		$headers = substr($response, 0, $nlnl);
		$cookies = 'Set-Cookie: ';
		if (preg_match_all('/^(.*?)(\r?\n|$)/ims', $headers, $matches))
			for ($i = 0; $i < count($matches[0]); ++$i) {
				if (stripos($matches[1][$i],'Content-Length') ===false ) {
					$ct = $matches[1][$i];
				}
				if (stripos($matches[1][$i],'Content-Type') !==false ) {
					$type=$types[substr($matches[1][$i],14)];
				}
				header($ct, false);
			}
		$doc.=substr($response, $nlnl + $add);
		$headers_processed = 1;
	} else
		$doc.=$r;
}
fclose ($fp);
$doc=str_replace($mirror,$_SERVER['SERVER_NAME'],$doc);
if($encrypt_page){
	$doc=encodePage($doc);
}
if ($gzip_page && isset($_SERVER['HTTP_ACCEPT_ENCODING']) && strpos($_SERVER['HTTP_ACCEPT_ENCODING'],'gzip') !== false && extension_loaded('zlib') && ! ini_get('zlib.output_compression') && $type!='image') {
	$doc=gzencode($doc, 6);
	header('Content-Encoding: gzip');
	header('Vary: Accept-Encoding');
}
header('Content-Length: '.strlen($doc));
echo $doc;
?>
